package com.glca.security.studentmanagement.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.glca.security.studentmanagement.entity.Student;

public interface StudentRepository extends JpaRepository<Student, Integer> {

}
