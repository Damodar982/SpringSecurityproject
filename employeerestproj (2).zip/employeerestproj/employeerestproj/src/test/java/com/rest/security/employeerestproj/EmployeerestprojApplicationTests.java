package com.rest.security.employeerestproj;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeerestprojApplicationTests {

	@Test
	void contextLoads() {
	}

}
