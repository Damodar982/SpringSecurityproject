package com.rest.security.employeerestproj;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeerestprojApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeerestprojApplication.class, args);
	}

}
