package com.rest.security.employeerestproj.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.rest.security.employeerestproj.entity.Role;

public interface RoleRepository extends JpaRepository<Role, Integer>{

}
