package com.rest.security.employeerestproj.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import com.rest.security.employeerestproj.dao.UserRepository;
import com.rest.security.employeerestproj.entity.User;
import com.rest.security.employeerestproj.security.MyUserDetails;

public class UserDeatilsServiceImpl implements UserDetailsService {

	@Autowired
	private UserRepository userRepository;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		
		
		User user =userRepository.getUserByUsername(username);
		
		if(user==null)
		{
			throw new UsernameNotFoundException("could not found user");
		}
		return new MyUserDetails(user);
	}
	
	
}
